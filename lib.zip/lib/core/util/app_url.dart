class AppUrl {
  static const tafseerUrl = 'assets/ar_muyassar.json';
  static const quranUrl = 'assets/quran_en.json';
  static const hadithUrl = 'assets/sections/hadith.json';
  static const adhkarUrl = 'assets/azkar.json';
  static const nameQuranUrl = 'assets/name_quran.json';
  static const nameOfAllahUrl = 'assets/Names_Of_Allah.json';
}
