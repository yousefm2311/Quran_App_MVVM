class AssetsData {
  static const ayah = 'assets/images/ayah.png';
  static const lantern = 'assets/images/lantern.png';
  static const mushaf = 'assets/images/mushaf.png';
  static const mushaf_1 = 'assets/images/mushaf_1.png';
  static const pngTree = 'assets/images/pngtree.png';
  static const adhan = 'assets/images/adhan.png';
  static const azkar = 'assets/images/azkar.png';
  static const moon = 'assets/images/moon.png';
  static const nameOfAllah = 'assets/images/nameofallah.png';
  static const qiblahImage = 'assets/images/qiblahImage.png';
  static const ramadan = 'assets/images/ramadan.png';
  static const coming = 'assets/images/json/coming.json';
  static const location = 'assets/images/json/location.json';
  static const notification = 'assets/images/json/noti.json';
  static const json_4 = 'assets/images/json/4.json';
  static const json_5 = 'assets/images/json/5.json';
  static const settings = 'assets/images/json/settings.json';
}