import 'package:flutter/material.dart';

class AppColors {
  static const kPrimaryColor = Color.fromRGBO(54, 180, 173, 1);
  static const kbackGroundColor = Color.fromRGBO(227, 241, 246, 1);
}
