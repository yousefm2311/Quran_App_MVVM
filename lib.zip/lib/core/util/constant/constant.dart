// ignore_for_file: prefer_typing_uninitialized_variables

const kTransitionDuration = Duration(milliseconds: 250);
const scrollPostition = 'scroll_position';
const bookMark = 'book';
const changeIndex_1 = "changeIndex";
const changeIndex_2 = "changeIndex2";
const changeIndex_3 = "changeIndex3";
const changeIndex_4 = "changeIndex4";
const tafseerIndex = "index";
